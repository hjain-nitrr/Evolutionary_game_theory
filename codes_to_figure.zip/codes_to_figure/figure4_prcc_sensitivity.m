function figure4_prcc_sensitivity()
% FIGURE4_PRCC_SENSITIVITY Generates PRCC tornado plots and heatmap.

    p = params();
    N = 1500;

    % Parameter ranges
    ranges.k       = [0.001, 0.30];
    ranges.Delta_d = [0.005, 0.06];
    ranges.epsHE   = [0.20, 0.45];
    ranges.epsLE   = [0.50, 0.75];
    ranges.Tref    = [270, 305];

    % Latin Hypercube sampling
    X = lhsdesign(N,5,'criterion','maximin','iterations',30);
    k_s     = ranges.k(1)       + X(:,1).*(ranges.k(2)-ranges.k(1));
    Dd_s    = ranges.Delta_d(1) + X(:,2).*(ranges.Delta_d(2)-ranges.Delta_d(1));
    epsHE_s = ranges.epsHE(1)   + X(:,3).*(ranges.epsHE(2)-ranges.epsHE(1));
    epsLE_s = ranges.epsLE(1)   + X(:,4).*(ranges.epsLE(2)-ranges.epsLE(1));
    Tref_s  = ranges.Tref(1)    + X(:,5).*(ranges.Tref(2)-ranges.Tref(1));

    Tstar = nan(N,1);
    xstar = nan(N,1);

    for i = 1:N
        % Override parameters in the structure
        p_temp = p;
        p_temp.epsilon_LE = epsLE_s(i);
        p_temp.epsilon_HE = epsHE_s(i);
        p_temp.T_ref = Tref_s(i);
        [Tstar(i), xstar(i), ~, ~, ~] = ...
            interior_equilibrium(k_s(i), Dd_s(i), Tref_s(i), p_temp);
    end

    % Remove invalid samples
    valid = ~isnan(Tstar);
    P = [k_s(valid), Dd_s(valid), epsHE_s(valid), epsLE_s(valid), Tref_s(valid)];
    T_valid = Tstar(valid);
    x_valid = xstar(valid);
    paramNames = {'k','\Delta d','\epsilon_{HE}','\epsilon_{LE}','T_{ref}'};

    % PRCC function (local, defined at end of file)
    prcc_T = rank_partial_corr(P, T_valid);
    prcc_x = rank_partial_corr(P, x_valid);

    % ---- Tornado plots ----
    figure('Name','Figure 4a,b','Position',[100 100 900 400],'Color','white');

    subplot(1,2,1);
    [~, ord1] = sort(abs(prcc_T), 'descend');
    barh(prcc_T(ord1), 'FaceColor', [0.18 0.45 0.78]);
    yticks(1:numel(ord1));
    yticklabels(paramNames(ord1));
    xlim([-1 1]); grid on;
    xlabel('PRCC'); title('For T^*');

    subplot(1,2,2);
    [~, ord2] = sort(abs(prcc_x), 'descend');
    barh(prcc_x(ord2), 'FaceColor', [0.20 0.63 0.42]);
    yticks(1:numel(ord2));
    yticklabels(paramNames(ord2));
    xlim([-1 1]); grid on;
    xlabel('PRCC'); title('For x^*');

    sgtitle('Figure 4a,b: PRCC sensitivity');
    exportgraphics(gcf, 'Figure4ab.png', 'Resolution', 300);

    % ---- Heatmap ----
    figure('Name','Figure 4c','Position',[200 200 600 400],'Color','white');
    H = [prcc_T(:)'; prcc_x(:)'];
    imagesc(H, [-1 1]); colormap(parula); colorbar;
    xticks(1:numel(paramNames)); xticklabels(paramNames);
    yticks([1 2]); yticklabels({'T^*','x^*'});
    title('PRCC heatmap');
    for r = 1:2
        for c = 1:numel(paramNames)
            text(c, r, sprintf('%.2f', H(r,c)), ...
                 'HorizontalAlignment','center', 'FontWeight','bold', 'Color','w');
        end
    end
    exportgraphics(gcf, 'Figure4c.png', 'Resolution', 300);
end

% Local PRCC function
function prcc = rank_partial_corr(X, y)
    n = size(X,1);
    p = size(X,2);
    Xr = zeros(size(X));
    for j = 1:p
        Xr(:,j) = tiedrank(X(:,j));
    end
    yr = tiedrank(y(:));
    prcc = nan(p,1);
    for j = 1:p
        idx = setdiff(1:p, j);
        Z = [ones(n,1), Xr(:,idx)];
        bx = Z \ Xr(:,j);
        by = Z \ yr;
        rx = Xr(:,j) - Z * bx;
        ry = yr - Z * by;
        C = corrcoef(rx, ry);
        prcc(j) = C(1,2);
    end
end