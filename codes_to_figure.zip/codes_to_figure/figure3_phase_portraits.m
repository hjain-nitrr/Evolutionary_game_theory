function figure3_phase_portraits()
% FIGURE3_PHASE_PORTRAITS Generates Figure 3 with four phase portraits.

    p = params();
    opts = odeset('RelTol',1e-8,'AbsTol',1e-10);
    tspan = [0 500];

    % Define four cases
    cases = {
        struct('k',0.001, 'T_ref',286, 'Delta_d',0.02, 'name','Only E0 stable');
        struct('k',0.4,   'T_ref',286, 'Delta_d',0.02, 'name','Only E1 stable');
        struct('k',0.02,  'T_ref',286, 'Delta_d',0.02, 'name','Only interior stable');
        struct('k',0.5,   'T_ref',160, 'Delta_d',0.02, 'name','Bistability (interior + E1)');
    };

    % Manually defined initial conditions (x0, T0)
    ICs = {
        [0.1,285; 0.3,290; 0.5,295; 0.7,300; 0.9,305; 0.2,295; 0.8,290; 0.8,350; 0.2,325];
        [0.1,365; 0.3,290; 0.5,355; 0.7,326; 0.9,355; 0.8,345; 0.8,370];
        [0.1,285; 0.3,290; 0.5,295; 0.7,300; 0.9,305; 0.2,295; 0.8,310; 0.9,340];
        { [0.2,310; 0.3,320; 0.4,330; 0.5,340; 0.6,350; 0.6,310], ...
          [0.8,360; 0.85,370; 0.96,330; 0.95,350; 0.98,305; 0.9,340] }
    };

    figure('Name','Figure 3','Position',[50 50 1200 900],'Color','white');

    for idx = 1:4
        c = cases{idx};
        k = c.k; T_ref_cur = c.T_ref; Delta_d_cur = c.Delta_d;
        T0_cur = p.T0_func(T_ref_cur);
        T1_cur = p.T1_func(T_ref_cur);

        % Temperature range
        if idx == 4
            T_lim = [280, 400]; T_range = linspace(280,400,500);
        else
            T_lim = [280, 310]; T_range = linspace(280,310,500);
        end
        x_lim = [0, 1.1];

        % T-nullcline
        x_null = (p.R./(p.sigma*T_range.^4) - p.epsilon_LE) / p.Delta_eps;

        % Interior equilibria
        [T_stable, x_stable, ~, ~, ~] = ...
            interior_equilibrium(k, Delta_d_cur, T_ref_cur, p);

        subplot(2,2,idx); hold on; box on; grid on;
        plot(x_null, T_range, 'b-', 'LineWidth', 2);
        plot([0 x_lim(2)], [T0_cur T0_cur], 'k--', 'LineWidth',1.2);
        plot([0 x_lim(2)], [T1_cur T1_cur], 'k--', 'LineWidth',1.2);
        plot(0, T0_cur, 'go', 'MarkerSize',10,'MarkerFaceColor','g');
        plot(1, T1_cur, 'ro', 'MarkerSize',10,'MarkerFaceColor','r');
        if ~isnan(T_stable)
            plot(x_stable, T_stable, 'bo', 'MarkerSize',10,'MarkerFaceColor','b');
        end

        % ODE system
        odefun = @(t, y) [
            (p.R - (p.epsilon_LE + y(2)*p.Delta_eps) * p.sigma * y(1)^4);
            y(2)*(1-y(2)) * (k * p.sigma * y(1)^4 * (p.epsilon_LE-p.epsilon_HE) ...
                             - Delta_d_cur * (y(1)-T_ref_cur)^2)
        ];

        % Trajectories
        if idx == 4
            ics_int = ICs{4}{1};
            ics_E1  = ICs{4}{2};
            for i = 1:size(ics_int,1)
                [~, sol] = ode45(odefun, tspan, [ics_int(i,2); ics_int(i,1)], opts);
                plot(sol(:,2), sol(:,1), 'Color', [0 0.4470 0.7410], 'LineWidth', 1.5);
            end
            for i = 1:size(ics_E1,1)
                [~, sol] = ode45(odefun, tspan, [ics_E1(i,2); ics_E1(i,1)], opts);
                plot(sol(:,2), sol(:,1), 'Color', [0.8 0.2 0.2], 'LineWidth', 1.5);
            end
        else
            ics = ICs{idx};
            for i = 1:size(ics,1)
                [~, sol] = ode45(odefun, tspan, [ics(i,2); ics(i,1)], opts);
                plot(sol(:,2), sol(:,1), 'Color', [0 0.4470 0.7410], 'LineWidth', 1.5);
            end
        end

        xlabel('HE fraction x'); ylabel('T (K)');
        title(sprintf('(%c) %s', char(96+idx), c.name));
        xlim(x_lim); ylim(T_lim);
    end
    sgtitle('Figure 3: Phase portraits for four dynamical regimes');
    exportgraphics(gcf, 'Figure3.png', 'Resolution', 300);
end