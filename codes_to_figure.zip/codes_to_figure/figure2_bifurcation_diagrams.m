function figure2_bifurcation_diagrams()
% FIGURE2_BIFURCATION_DIAGRAMS Generates Figure 2 (a) full algebraic, (b) admissible branch.

    p = params();
    T_ref = p.T_ref;
    Delta_d = p.Delta_d;
    sigma = p.sigma;
    R = p.R;
    epsilon_LE = p.epsilon_LE;
    epsilon_HE = p.epsilon_HE;

    T0 = p.T0_func(T_ref);
    T1 = p.T1_func(T_ref);

    % Full algebraic branches (k up to 1.2)
    k_full = linspace(0.01, 1.2, 600);
    T_plus_full = nan(size(k_full));
    T_minus_full = nan(size(k_full));
    for i = 1:length(k_full)
        [Ts, ~, Tp, ~, ~] = interior_equilibrium(k_full(i), Delta_d, T_ref, p);
        T_minus_full(i) = Ts;
        T_plus_full(i)  = Tp;
    end

    % Admissible branch (k up to 0.5)
    k_adm = linspace(0.01, 0.5, 500);
    T_minus_adm = nan(size(k_adm));
    for i = 1:length(k_adm)
        [Ts, ~, ~, ~, ~] = interior_equilibrium(k_adm(i), Delta_d, T_ref, p);
        T_minus_adm(i) = Ts;
    end

    % Saddle-node point
    k_SN = 1 / (16 * T_ref^2 * p.alpha(Delta_d));
    T_SN = 2 * T_ref;

    % Transcritical thresholds
    k_trans0 = Delta_d * (T0 - T_ref)^2 / (sigma * T0^4 * (epsilon_LE - epsilon_HE));
    k_trans1 = Delta_d * (T1 - T_ref)^2 / (sigma * T1^4 * (epsilon_LE - epsilon_HE));

    % ---- Figure 2(a) ----
    figure('Name','Figure 2a','Position',[100 100 850 500],'Color','white');
    hold on; box on; grid on;
    plot(k_full, T_minus_full, 'b-', 'LineWidth', 2.2);
    plot(k_full, T_plus_full,  'r--','LineWidth', 2.2);
    plot(k_full, T0*ones(size(k_full)), 'k--', 'LineWidth', 1.5);
    plot(k_full, T1*ones(size(k_full)), 'k--', 'LineWidth', 1.5);
    plot(k_SN, T_SN, 'ko', 'MarkerSize', 10, 'MarkerFaceColor','k');
    text(k_SN, T_SN+3, sprintf('Saddle-node\nk = %.3f', k_SN), ...
         'HorizontalAlignment','center');
    xlabel('k'); ylabel('T^* (K)');
    title('(a) Full algebraic bifurcation');
    legend('Stable interior','Saddle','E0','E1','Location','best');
    xlim([0 1.2]); ylim([280 380]);
    hold off;
    exportgraphics(gcf, 'Figure2a.png', 'Resolution', 300);

    % ---- Figure 2(b) ----
    figure('Name','Figure 2b','Position',[150 150 850 500],'Color','white');
    hold on; box on; grid on;
    plot(k_adm, T_minus_adm, 'b-', 'LineWidth', 2.2);
    plot(k_adm, T0*ones(size(k_adm)), 'k--', 'LineWidth', 1.5);
    plot(k_adm, T1*ones(size(k_adm)), 'k--', 'LineWidth', 1.5);
    xline(k_trans0, 'm--', sprintf('k_{c0}=%.3f', k_trans0));
    xline(k_trans1, 'c--', sprintf('k_{c1}=%.3f', k_trans1));
    xlabel('k'); ylabel('T^* (K)');
    title('(b) Physically admissible interior branch');
    legend('Stable interior','E0','E1','Location','best');
    xlim([0 0.5]); ylim([280 310]);
    hold off;
    exportgraphics(gcf, 'Figure2b.png', 'Resolution', 300);
end