function figure1_effect_Delta_d()
% FIGURE1_EFFECT_DELTA_D Generates Figure 1: T* and x* vs Delta_d.

    p = params();
    k_fixed = 0.20;
    T_ref = p.T_ref;

    Delta_d_vec = linspace(0.005, 0.1, 200);
    T_star = nan(size(Delta_d_vec));
    x_star = nan(size(Delta_d_vec));

    for i = 1:length(Delta_d_vec)
        [T_star(i), x_star(i), ~, ~, ~] = ...
            interior_equilibrium(k_fixed, Delta_d_vec(i), T_ref, p);
    end

    figure('Name','Figure 1','Position',[100 100 900 400],'Color','white');
    subplot(1,2,1);
    plot(Delta_d_vec, T_star, 'b-', 'LineWidth', 2.2);
    xlabel('\Delta d'); ylabel('T^* (K)');
    title(sprintf('k = %.2f', k_fixed));
    grid on; box on;

    subplot(1,2,2);
    plot(Delta_d_vec, x_star, 'r-', 'LineWidth', 2.2);
    xlabel('\Delta d'); ylabel('x^*');
    title(sprintf('k = %.2f', k_fixed));
    grid on; box on;

    sgtitle('Figure 1: Effect of asymmetric damage on interior equilibrium');
    exportgraphics(gcf, 'Figure1.png', 'Resolution', 300);
end