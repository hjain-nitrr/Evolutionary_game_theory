function [T_stable, x_stable, T_saddle, x_saddle, exists] = ...
    interior_equilibrium(k, Delta_d, T_ref, p)
% INTERIOR_EQUILIBRIUM Computes all admissible interior equilibria.
%   [T_stable, x_stable, T_saddle, x_saddle, exists] = ...
%       interior_equilibrium(k, Delta_d, T_ref, p)
%   Returns the stable node (lower branch), the saddle (upper branch),
%   and a flag indicating if at least one interior equilibrium exists.

    if nargin < 4, p = params(); end

    epsilon_LE = p.epsilon_LE;
    epsilon_HE = p.epsilon_HE;
    sigma = p.sigma;
    R = p.R;

    alpha = sigma * (epsilon_LE - epsilon_HE) / Delta_d;
    K = alpha * k;
    sqrtK = sqrt(K);
    disc = 1 - 4 * sqrtK * T_ref;

    T_stable = NaN; x_stable = NaN;
    T_saddle  = NaN; x_saddle  = NaN;
    exists = false;

    if disc >= 0
        Tm = (1 - sqrt(disc)) / (2 * sqrtK);
        Tp = (1 + sqrt(disc)) / (2 * sqrtK);

        % Lower branch (stable node)
        if Tm >= T_ref
            xm = (1/(epsilon_HE - epsilon_LE)) * (R/(sigma * Tm^4) - epsilon_LE);
            if xm > 0 && xm < 1
                T_stable = Tm;
                x_stable = xm;
                exists = true;
            end
        end

        % Upper branch (saddle)
        if Tp >= T_ref
            xp = (1/(epsilon_HE - epsilon_LE)) * (R/(sigma * Tp^4) - epsilon_LE);
            if xp > 0 && xp < 1
                T_saddle = Tp;
                x_saddle = xp;
            end
        end
    end
end