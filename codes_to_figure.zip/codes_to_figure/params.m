function p = params()
% PARAMS Returns a structure with all baseline parameters and helper functions.

    p.sigma = 5.67e-8;          % Stefan-Boltzmann constant (W m^-2 K^-4)
    p.R     = 239.4;            % Absorbed solar radiation (W m^-2)
    p.C     = 1e9;              % Effective heat capacity (J m^-2 K^-1)

    p.epsilon_LE = 0.6;         % LE emissivity
    p.epsilon_HE = 0.3;         % HE emissivity
    p.Delta_eps  = p.epsilon_HE - p.epsilon_LE;   % < 0

    p.d_LE = 0.01;              % LE damage coefficient (baseline)
    p.Delta_d = 0.02;           % Default damage asymmetry
    p.T_ref = 286;              % Reference temperature (K)

    % Helper functions
    p.T0_func = @(Tref) (p.R / (p.epsilon_LE * p.sigma))^(1/4);
    p.T1_func = @(Tref) (p.R / (p.epsilon_HE * p.sigma))^(1/4);
    p.x_from_T = @(T) (1/p.Delta_eps) * (p.R/(p.sigma * T^4) - p.epsilon_LE);
    p.alpha = @(Delta_d) p.sigma * (p.epsilon_LE - p.epsilon_HE) / Delta_d;

    % Payoff difference and its derivative
    p.Delta_pi = @(T, k, Delta_d, Tref) ...
        k * p.sigma * T^4 * (p.epsilon_LE - p.epsilon_HE) ...
        - Delta_d * (T - Tref)^2;
    p.Phi = @(T, k, Delta_d, Tref) ...
        4 * k * p.sigma * T^3 * (p.epsilon_LE - p.epsilon_HE) ...
        - 2 * Delta_d * (T - Tref);
end