function figure5_safe_operating_space()
% FIGURE5_SAFE_OPERATING_SPACE Generates regime map and T*, x* maps.

    p = params();
    T_ref = p.T_ref;

    k_grid = linspace(0.001, 0.40, 220);
    Dd_grid = linspace(0.001, 0.06, 220);
    [K, D] = meshgrid(k_grid, Dd_grid);

    Z = nan(size(K));    % regime code
    Tmap = nan(size(K));
    xmap = nan(size(K));

    for j = 1:numel(K)
        k = K(j);
        Delta_d = D(j);
        [reg, Ts, xs] = classify_regime(k, Delta_d, T_ref, p);
        Z(j) = reg;
        Tmap(j) = Ts;
        xmap(j) = xs;
    end

    % ---- Regime map ----
    figure('Name','Figure 5a','Position',[100 100 800 600],'Color','white');
    imagesc(k_grid, Dd_grid, Z);
    set(gca,'YDir','normal');
    mapcolors = [0.23 0.68 0.31;   % green
                 0.16 0.44 0.82;   % blue
                 0.86 0.29 0.18;   % red
                 0.62 0.34 0.74];  % purple for coexistence (not used)
    colormap(mapcolors);
    caxis([1 4]);
    cb = colorbar;
    cb.Ticks = [1.375 2.125 2.875 3.625];
    cb.TickLabels = {'Only E0','Interior','Only E1','Coexistence'};
    xlabel('k'); ylabel('\Delta d');
    title('Figure 5a: Regime map');
    exportgraphics(gcf, 'Figure5a.png', 'Resolution', 300);

    % ---- T* map ----
    figure('Name','Figure 5b','Position',[150 150 800 600],'Color','white');
    imagesc(k_grid, Dd_grid, Tmap);
    set(gca,'YDir','normal');
    colorbar;
    xlabel('k'); ylabel('\Delta d');
    title('Figure 5b: Stable interior T^*');
    exportgraphics(gcf, 'Figure5b.png', 'Resolution', 300);

    % ---- x* map ----
    figure('Name','Figure 5c','Position',[200 200 800 600],'Color','white');
    imagesc(k_grid, Dd_grid, xmap);
    set(gca,'YDir','normal');
    colorbar;
    xlabel('k'); ylabel('\Delta d');
    title('Figure 5c: Stable interior x^*');
    exportgraphics(gcf, 'Figure5c.png', 'Resolution', 300);
end

% Helper: classify regime for a given (k, Delta_d)
function [regime, Tstable, xstable] = classify_regime(k, Delta_d, T_ref, p)
    Tstable = NaN; xstable = NaN;
    T0 = p.T0_func(T_ref);
    T1 = p.T1_func(T_ref);

    dpi0 = p.Delta_pi(T0, k, Delta_d, T_ref);
    dpi1 = p.Delta_pi(T1, k, Delta_d, T_ref);
    E0_stable = (dpi0 < 0);
    E1_stable = (dpi1 > 0);

    [T_int, x_int, ~, ~, exists] = interior_equilibrium(k, Delta_d, T_ref, p);
    interior_stable = exists && p.Phi(T_int, k, Delta_d, T_ref) < 0;

    if interior_stable
        Tstable = T_int;
        xstable = x_int;
    end

    if E0_stable && ~E1_stable && ~interior_stable
        regime = 1;
    elseif ~E0_stable && ~E1_stable && interior_stable
        regime = 2;
    elseif ~E0_stable && E1_stable && ~interior_stable
        regime = 3;
    elseif interior_stable && (E0_stable || E1_stable)
        regime = 4;
    else
        regime = 2; % fallback
    end
end