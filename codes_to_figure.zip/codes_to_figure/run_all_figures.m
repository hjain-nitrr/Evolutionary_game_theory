function run_all_figures()
% RUN_ALL_FIGURES Generates all figures for the manuscript.

    fprintf('Generating Figure 1...\n');
    figure1_effect_Delta_d();

    fprintf('Generating Figure 2...\n');
    figure2_bifurcation_diagrams();

    fprintf('Generating Figure 3...\n');
    figure3_phase_portraits();

    fprintf('Generating Figure 4...\n');
    figure4_prcc_sensitivity();

    fprintf('Generating Figure 5...\n');
    figure5_safe_operating_space();

    fprintf('All figures generated and saved as PNG.\n');
end